var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {

  const values=["alhusna","zayn","zinadine","zidane"]
  const person={name:"Ajsal",admin:true}
  res.render('index',{person,values});
  
});

module.exports = router;
